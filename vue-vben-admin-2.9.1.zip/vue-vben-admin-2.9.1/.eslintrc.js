module.exports = {
  root: true,
  extends: ['@vben'],
};
