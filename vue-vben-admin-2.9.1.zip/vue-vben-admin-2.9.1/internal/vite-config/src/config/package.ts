function definePackageConfig() {
  // TODO:
}

export { definePackageConfig };
