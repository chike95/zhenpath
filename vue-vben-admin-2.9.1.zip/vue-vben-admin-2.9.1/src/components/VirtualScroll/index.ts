import { withInstall } from '/@/utils/index';
import vScroll from './src/VirtualScroll.vue';

export const VScroll = withInstall(vScroll);
