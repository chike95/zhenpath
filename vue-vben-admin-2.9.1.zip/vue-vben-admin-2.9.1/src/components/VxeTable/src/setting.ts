import { VXETable } from '..';
import componentSetting from '/@/settings/componentSetting';

VXETable.setup(componentSetting.vxeTable);
