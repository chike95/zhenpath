import { createFormItemRender } from './common';

export default {
  renderItemContent: createFormItemRender(),
};
