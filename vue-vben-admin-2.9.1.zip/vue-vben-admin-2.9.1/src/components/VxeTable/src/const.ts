/**
 * @description: 传给vxe-table 时需要忽略的prop
 */
export const ignorePropKeys = ['tableClass', 'tableStyle'];
