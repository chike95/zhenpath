import { withInstall } from '/@/utils';
import dropdown from './src/Dropdown.vue';

export * from './src/typing';
export const Dropdown = withInstall(dropdown);
