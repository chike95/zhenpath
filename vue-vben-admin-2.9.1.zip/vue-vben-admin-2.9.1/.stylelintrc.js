module.exports = {
  root: true,
  extends: ['@vben/stylelint-config'],
};
